from setuptools import setup

setup(name="calculos",
      version="1.0",
      description="Paquete de cálculos matemáticos",
      author="Alexis Sáez",
      author_email="cucoalexis@hotmail.com",
      url="https://imalexissaez.github.io/",
      packages=["calculos"])